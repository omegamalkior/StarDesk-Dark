StarDesk dark theme - developer integration, as a pull request
==============================================================

Laid out the way it would be sent to StarDesk if the client's source were on GitHub
(branch feature/dark-theme -> main, 14 commits).

  Pull request.html          the pull request page: description, commits and every changed file.
                             Open it in a browser.
  PULL_REQUEST.md            the pull request description on its own
  patches/0001..0014         the 14 commits. On a branch from main:  git am patches/*.patch
  integration-points.diff    the changes to existing StarDesk files (also commit 0006). Written
                             without the StarDesk source, so they are anchored by function and
                             placed by hand.

File paths follow StarDesk's own source layout (src/client_ui/uikit/..., src/client_ui/shell/
features/..., src/apps/client/main.cpp) as it appears in the 1.6.0.166 client.
